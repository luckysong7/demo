package com.naver;

interface Naver {

	public void input() throws Exception;

	public void print();

	public void searchId();

}
